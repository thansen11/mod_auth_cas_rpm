#ifndef CURL_STUBS_H
#define CURL_STUBS_H

void set_curl_response(const char *response);

#endif /* def CURL_STUBS_H */
